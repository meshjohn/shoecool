export const categories = [
  {
    id: 0,
    title: "Men",
    name: "men",
  },
  {
    id: 1,
    title: "Women",
    name: "women",
  },
  {
    id: 3,
    title: "Kids",
    name: "kids",
  },
];
